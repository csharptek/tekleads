using TEKLead.Api.Data;
using TEKLead.Api.Middleware;
using TEKLead.Api.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers()
    .AddJsonOptions(o => o.JsonSerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase);
builder.Services.AddHttpClient();
builder.Services.AddSingleton<SettingsService>();
builder.Services.AddScoped<LeadService>();
builder.Services.AddScoped<ApolloService>();
builder.Services.AddScoped<WebSearchService>();
builder.Services.AddScoped<PortfolioService>();
builder.Services.AddScoped<ProposalService>();
builder.Services.AddScoped<ProposalCompanyContextService>();
builder.Services.AddScoped<ProposalGenerationService>();
builder.Services.AddScoped<BlobService>();
builder.Services.AddSingleton<FileStorageService>();
builder.Services.AddScoped<LogService>();
builder.Services.AddScoped<ProposalExportService>();
builder.Services.AddScoped<ArtifactsService>();
builder.Services.AddScoped<JdQualityService>();
builder.Services.AddScoped<ArtifactChatService>();
builder.Services.AddScoped<GraphEmailService>();
builder.Services.AddScoped<GmailSmtpService>();
builder.Services.AddScoped<EmailSendQueueService>();
builder.Services.AddScoped<QuickOutreachEnrichedService>();
builder.Services.AddScoped<ContactListService>();
builder.Services.AddScoped<InstantlyService>();
builder.Services.AddScoped<WhatsAppCloudService>();
builder.Services.AddScoped<ProductService>();
builder.Services.AddScoped<ProductAIService>();
builder.Services.AddScoped<WaScheduleService>();
builder.Services.AddScoped<ProductsDbInitializer>();
builder.Services.AddScoped<JobScraperService>();
builder.Services.AddScoped<JobLeadContactService>();
builder.Services.AddScoped<JobLeadContactPickerService>();
builder.Services.AddScoped<JobLeadArtifactsService>();
builder.Services.AddScoped<JobLeadEmailQueueService>();
builder.Services.AddHostedService<EmailSendWorker>();
builder.Services.AddHostedService<PhoneWebhookWorker>();
builder.Services.AddHostedService<WaScheduleWorker>();
builder.Services.AddHostedService<JobLeadEmailWorker>();
builder.Services.AddCors(o => o.AddDefaultPolicy(p =>
    p.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader()
     .WithExposedHeaders("Access-Control-Allow-Private-Network")));

builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.SetMinimumLevel(LogLevel.Information);

var app = builder.Build();

var port = Environment.GetEnvironmentVariable("PORT");
if (!string.IsNullOrEmpty(port) && string.IsNullOrEmpty(Environment.GetEnvironmentVariable("ASPNETCORE_URLS")))
    app.Urls.Add($"http://0.0.0.0:{port}");

app.Use(async (ctx, next) =>
{
    try { await next(); }
    catch (Exception ex)
    {
        ctx.Response.StatusCode = 500;
        ctx.Response.Headers["Access-Control-Allow-Origin"] = "*";
        ctx.Response.ContentType = "application/json";
        var msg = ex.Message.Replace("\"", "'");
        await ctx.Response.WriteAsync("{\"error\":\"" + msg + "\"}");
    }
});
app.UseCors();

// Chrome 130+ Private Network Access — required for newer Android devices
app.Use(async (ctx, next) =>
{
    if (ctx.Request.Headers.ContainsKey("Access-Control-Request-Private-Network"))
        ctx.Response.Headers["Access-Control-Allow-Private-Network"] = "true";
    await next();
});
app.UseRequestLogging();
app.MapGet("/", () => Results.Ok(new { service = "tekleads-api", phase = 2 }));
app.MapGet("/health", () => Results.Ok(new { status = "ok", time = DateTime.UtcNow }));

using (var scope = app.Services.CreateScope())
{
    var settings = scope.ServiceProvider.GetRequiredService<SettingsService>();
    var leadSvc  = scope.ServiceProvider.GetRequiredService<LeadService>();
    try { await settings.EnsureSchema(); } catch (Exception ex) { app.Logger.LogError(ex, "Settings schema failed"); }
    try { await leadSvc.EnsureSchema();  } catch (Exception ex) { app.Logger.LogError(ex, "Leads schema failed"); }
    try { var portSvc = scope.ServiceProvider.GetRequiredService<PortfolioService>(); await portSvc.EnsureSchema(); } catch (Exception ex) { app.Logger.LogError(ex, "Portfolio schema failed"); }
    try { var propSvc = scope.ServiceProvider.GetRequiredService<ProposalService>(); await propSvc.EnsureSchema(); } catch (Exception ex) { app.Logger.LogError(ex, "Proposal schema failed"); }
    try { var compCtxSvc = scope.ServiceProvider.GetRequiredService<ProposalCompanyContextService>(); await compCtxSvc.EnsureSchema(); } catch (Exception ex) { app.Logger.LogError(ex, "CompanyContext schema failed"); }
    try { var logSvc = scope.ServiceProvider.GetRequiredService<LogService>(); await logSvc.EnsureSchema(); } catch (Exception ex) { app.Logger.LogError(ex, "Log schema failed"); }
    try { var genSvc = scope.ServiceProvider.GetRequiredService<ProposalGenerationService>(); await genSvc.EnsureSchema(); } catch (Exception ex) { app.Logger.LogError(ex, "ProposalGeneration schema failed"); }
    try { var artSvc = scope.ServiceProvider.GetRequiredService<ArtifactsService>(); await artSvc.EnsureSchema(); } catch (Exception ex) { app.Logger.LogError(ex, "Artifacts schema failed"); }
    try { var jdSvc = scope.ServiceProvider.GetRequiredService<JdQualityService>(); await jdSvc.EnsureSchema(); } catch (Exception ex) { app.Logger.LogError(ex, "JdQuality schema failed"); }
    try { var artChatSvc = scope.ServiceProvider.GetRequiredService<ArtifactChatService>(); await artChatSvc.EnsureSchema(); } catch (Exception ex) { app.Logger.LogError(ex, "ArtifactChat schema failed"); }
    try { var queueSvc = scope.ServiceProvider.GetRequiredService<EmailSendQueueService>(); await queueSvc.EnsureSchema(); } catch (Exception ex) { app.Logger.LogError(ex, "EmailSendQueue schema failed"); }
    try { var qoeSvc = scope.ServiceProvider.GetRequiredService<QuickOutreachEnrichedService>(); await qoeSvc.EnsureSchema(); } catch (Exception ex) { app.Logger.LogError(ex, "QuickOutreachEnriched schema failed"); }
    try { var clSvc = scope.ServiceProvider.GetRequiredService<ContactListService>(); await clSvc.EnsureSchema(); } catch (Exception ex) { app.Logger.LogError(ex, "ContactList schema failed"); }
    try { var waSvc = scope.ServiceProvider.GetRequiredService<WhatsAppCloudService>(); await waSvc.EnsureSchema(); } catch (Exception ex) { app.Logger.LogError(ex, "WhatsApp schema failed"); }
    try { var wasSvc = scope.ServiceProvider.GetRequiredService<WaScheduleService>(); await wasSvc.EnsureSchema(); } catch (Exception ex) { app.Logger.LogError(ex, "WaSchedule schema failed"); }
    try { var prodDb = scope.ServiceProvider.GetRequiredService<ProductsDbInitializer>(); await prodDb.EnsureSchema(); } catch (Exception ex) { app.Logger.LogError(ex, "Products schema failed"); }
    try { var jobsSvc = scope.ServiceProvider.GetRequiredService<JobScraperService>(); await jobsSvc.EnsureSchema(); } catch (Exception ex) { app.Logger.LogError(ex, "JobScraper schema failed"); }
    try { var jleQueue = scope.ServiceProvider.GetRequiredService<JobLeadEmailQueueService>(); await jleQueue.EnsureSchema(); } catch (Exception ex) { app.Logger.LogError(ex, "JobLeadEmailQueue schema failed"); }
    try { var pickerSvc = scope.ServiceProvider.GetRequiredService<JobLeadContactPickerService>(); await pickerSvc.EnsureSchema(); } catch (Exception ex) { app.Logger.LogError(ex, "JobLeadContactPicker schema failed"); }
}

app.MapControllers();
app.Run();
